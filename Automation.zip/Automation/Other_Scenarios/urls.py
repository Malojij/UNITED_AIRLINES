from Other_Scenarios import views
from django.urls import path

urlpatterns = [
    path('', views.Other_Scenarios, name="Other_Scenarios"),
]
