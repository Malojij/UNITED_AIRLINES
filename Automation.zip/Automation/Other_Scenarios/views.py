from django.shortcuts import render

def Other_Scenarios(request):
   return render(request, 'Other_Scenarios.html')
