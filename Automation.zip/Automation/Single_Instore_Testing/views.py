from django.shortcuts import render

class Single_Instore_Testing:

    def Single_Instore_Testing(self, request):
            return render(request, 'Single_Instore_Testing.html')