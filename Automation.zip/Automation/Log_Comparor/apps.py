from django.apps import AppConfig


class LogComparorConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Log_Comparor'
