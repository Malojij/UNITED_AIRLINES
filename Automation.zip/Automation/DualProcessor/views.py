from django.shortcuts import render


def DualProcessor(request):
   return render(request, 'Dual_Processor.html')